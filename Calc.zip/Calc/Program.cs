﻿using OpenQA.Selenium;
using OpenQA.Selenium.Edge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Calc
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new EdgeDriver();
            driver.Navigate().GoToUrl("https://www.calculatorsoup.com/calculators/math/basic.php");
            driver.Manage().Window.Maximize();

            driver.FindElement(By.Name("cs_one")).Click();
            driver.FindElement(By.Name("cs_four")).Click();
            Thread.Sleep(2000);
            driver.FindElement(By.Name("cs_add")).Click();
            Thread.Sleep(2000);
            driver.FindElement(By.Name("cs_two")).Click();
            driver.FindElement(By.Name("cs_one")).Click();
            Thread.Sleep(3000);

            driver.FindElement(By.Name("cs_equal")).Click();
            Thread.Sleep(2000);
            String str = driver.FindElement(By.Name("cs_display")).Text;
            
            Console.WriteLine(str);
            Thread.Sleep(2000);

            driver.Close();
            driver.Quit();   
        }
    }
}
